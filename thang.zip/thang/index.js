const cards = document.querySelectorAll('.h4')
const divImages = document.querySelectorAll('.img-standard')

const observer = new IntersectionObserver(entries => {
    entries.forEach(entry => {
        const { target } = entry;
        target.classList.toggle('active', entry.isIntersecting)
    })
}, {})

cards.forEach(card => {
    observer.observe(card)
})

divImages.forEach(card => {
    observer.observe(card)
})